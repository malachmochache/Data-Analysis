# Display Employee Details using R

This R script extracts a ZIP archive containing employee data, listing its contents, and displaying the contents of the CSV file found within the archive.

## 📦 Features

- Automatically checks and installs the `readr` package if not present.
- Unzips the file `Employee Profile.zip` to a local directory.
- Lists all extracted files from the ZIP archive.
- Searches for CSV files within the extracted contents.
- Loads and displays a preview of the CSV file.

## 🛠 Requirements

- R (version 3.5 or higher recommended)
- Internet connection (for automatic package installation if `readr` is missing)

## 📂 File Structure

- `display_data.R`: R script to unzip and display the CSV contents.
- `Employee Profile.zip`: Contains the `.csv` file.
- `Employee Profile/`: Directory where files will be extracted.


# 🚀 **How to Run**

1. Make sure `Employee Profile.zip` is located in your working directory.
2. Open the script in RStudio
3. Select all and run
3. You can also run the script from the RStudio's terminal using the following command:
    ```r
    Rscript "display_data.R"
    ```

3. The script will:
   - Unzip the archive
   - List the extracted files
   - Load and preview the CSV file

## 🧾 Output

- A message confirming successful extraction
- A list of extracted files
- A preview of the CSV file

## ❗ Error Handling

- If the ZIP file cannot be unzipped, the script will print an error message and stop.
- If no files or no CSV files are found, appropriate messages will be displayed.
- If the CSV cannot be read, a warning is printed, and the script continues safely.

## 📄 Example Output

```r
ZIP file extracted to: Employee Profile 
Extracted Files:
[1] "Employee Profile/employees.csv"
CSV file loaded successfully. Here's a preview:
# A tibble: 1 × 9
  EmployeeName      JobTitle     BasePay OvertimePay OtherPay Benefits TotalPay
  <chr>             <chr>          <dbl>       <dbl>    <dbl> <chr>       <dbl>
1 TSEHAINESH LEGESE ELIGIBILITY…  21745.        460.     310. Not Pro…   22515.
# ℹ 2 more variables: TotalPayBenefits <dbl>, Year <dbl>
...
```